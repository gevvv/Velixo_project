
            const scriptUrl = new URL("https://res.cdn.office.net/officehub/officestartbundles/36279.6c69e359857ded7bf4dc.chunk.js");
            const originalImportScripts = self.importScripts;
            self.importScripts = (url) => originalImportScripts.call(self, new URL(url, scriptUrl).toString());
            importScripts(scriptUrl.toString());
        